package filmator;

import org.junit.Test;

public class ExemploDeTeste {

	@Test
	public void teste() throws Exception {
		
	}
}
