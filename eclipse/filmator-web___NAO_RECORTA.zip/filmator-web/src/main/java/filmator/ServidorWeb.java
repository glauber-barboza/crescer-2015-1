package filmator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ServidorWeb {
	
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(ServidorWeb.class, args);
	}
}
