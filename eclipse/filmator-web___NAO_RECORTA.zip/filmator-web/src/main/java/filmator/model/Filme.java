package filmator.model;

public class Filme {

	private String nome;
	
	public Filme(String nome){
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
}
